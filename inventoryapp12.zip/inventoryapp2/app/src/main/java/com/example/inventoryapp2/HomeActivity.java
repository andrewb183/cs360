package com.example.inventoryapp2;

public class HomeActivity {
}
